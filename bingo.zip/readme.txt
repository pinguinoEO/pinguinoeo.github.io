This is SpeedRunTools bingo but modified to not balance the rows. It's also uglier.

- ping